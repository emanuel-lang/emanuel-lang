<?php
if (!defined('SIGEIA_APP')) { http_response_code(403); exit; }
return json_decode(<<<'SIGEIA_JSON'
{
  "regions": [
    {
      "id": "r1",
      "name": "Región Centro",
      "code": "RC-01",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ],
  "territories": [
    {
      "id": "t1",
      "name": "Territorio Alameda",
      "code": "TA-01",
      "regionId": "r1",
      "polygon": [
        [
          19.442,
          -99.155
        ],
        [
          19.442,
          -99.139
        ],
        [
          19.432,
          -99.139
        ],
        [
          19.432,
          -99.155
        ]
      ],
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "t2",
      "name": "Territorio Reforma",
      "code": "TR-02",
      "regionId": "r1",
      "polygon": [
        [
          19.431,
          -99.168
        ],
        [
          19.431,
          -99.152
        ],
        [
          19.421,
          -99.152
        ],
        [
          19.421,
          -99.168
        ]
      ],
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "t3",
      "name": "Territorio Centro",
      "code": "TC-03",
      "regionId": "r1",
      "polygon": [
        [
          19.435,
          -99.137
        ],
        [
          19.435,
          -99.123
        ],
        [
          19.425,
          -99.123
        ],
        [
          19.425,
          -99.137
        ]
      ],
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ],
  "localities": [
    {
      "id": "l1",
      "name": "Alameda Norte",
      "territoryId": "t1",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "l2",
      "name": "Reforma Poniente",
      "territoryId": "t2",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "l3",
      "name": "Centro Histórico",
      "territoryId": "t3",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ],
  "sectors": [
    {
      "id": "s1",
      "name": "Sector A-01",
      "localityId": "l1",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "s2",
      "name": "Sector R-01",
      "localityId": "l2",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "s3",
      "name": "Sector C-01",
      "localityId": "l3",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ],
  "roles": [
    {
      "id": "role1",
      "name": "Coordinación",
      "description": "Coordinación territorial (clasificación operativa, no concede acceso al sistema).",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "role2",
      "name": "Operación de campo",
      "description": "Registro y seguimiento territorial (clasificación operativa).",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ],
  "operators": [
    {
      "id": "o1",
      "name": "Operador demo 01",
      "roleId": "role1",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "o2",
      "name": "Operador demo 02",
      "roleId": "role2",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "o3",
      "name": "Operador demo 03",
      "roleId": "role2",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ],
  "assignments": [
    {
      "id": "a1",
      "operatorId": "o1",
      "level": "Región",
      "targetId": "r1",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "a2",
      "operatorId": "o2",
      "level": "Territorio",
      "targetId": "t1",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "a3",
      "operatorId": "o3",
      "level": "Sector",
      "targetId": "s2",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ],
  "houses": [
    {
      "id": "h1",
      "name": "Casa demo 01",
      "address": "Dirección ficticia 1",
      "sectorId": "s1",
      "status": "Visitada",
      "lat": 19.437,
      "lng": -99.149,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h2",
      "name": "Casa demo 02",
      "address": "Dirección ficticia 2",
      "sectorId": "s2",
      "status": "Visitada",
      "lat": 19.426,
      "lng": -99.161,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h3",
      "name": "Casa demo 03",
      "address": "Dirección ficticia 3",
      "sectorId": "s3",
      "status": "Visitada",
      "lat": 19.43,
      "lng": -99.132,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h4",
      "name": "Casa demo 04",
      "address": "Dirección ficticia 4",
      "sectorId": "s1",
      "status": "Visitada",
      "lat": 19.437800000000003,
      "lng": -99.148,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h5",
      "name": "Casa demo 05",
      "address": "Dirección ficticia 5",
      "sectorId": "s2",
      "status": "Visitada",
      "lat": 19.4268,
      "lng": -99.16,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h6",
      "name": "Casa demo 06",
      "address": "Dirección ficticia 6",
      "sectorId": "s3",
      "status": "Visitada",
      "lat": 19.4308,
      "lng": -99.131,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h7",
      "name": "Casa demo 07",
      "address": "Dirección ficticia 7",
      "sectorId": "s1",
      "status": "Visitada",
      "lat": 19.4386,
      "lng": -99.147,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h8",
      "name": "Casa demo 08",
      "address": "Dirección ficticia 8",
      "sectorId": "s2",
      "status": "Visitada",
      "lat": 19.427599999999998,
      "lng": -99.159,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h9",
      "name": "Casa demo 09",
      "address": "Dirección ficticia 9",
      "sectorId": "s3",
      "status": "Pendiente",
      "lat": 19.4316,
      "lng": -99.13000000000001,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h10",
      "name": "Casa demo 10",
      "address": "Dirección ficticia 10",
      "sectorId": "s1",
      "status": "Pendiente",
      "lat": 19.439400000000003,
      "lng": -99.146,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h11",
      "name": "Casa demo 11",
      "address": "Dirección ficticia 11",
      "sectorId": "s2",
      "status": "Pendiente",
      "lat": 19.4284,
      "lng": -99.158,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "h12",
      "name": "Casa demo 12",
      "address": "Dirección ficticia 12",
      "sectorId": "s3",
      "status": "Pendiente",
      "lat": 19.4324,
      "lng": -99.129,
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ],
  "citizens": [
    {
      "id": "c1",
      "name": "Ciudadano ficticio 01",
      "houseId": "h1",
      "status": "Verificado",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "c2",
      "name": "Ciudadano ficticio 02",
      "houseId": "h2",
      "status": "Verificado",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "c3",
      "name": "Ciudadano ficticio 03",
      "houseId": "h3",
      "status": "Verificado",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "c4",
      "name": "Ciudadano ficticio 04",
      "houseId": "h4",
      "status": "Verificado",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "c5",
      "name": "Ciudadano ficticio 05",
      "houseId": "h5",
      "status": "Verificado",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "c6",
      "name": "Ciudadano ficticio 06",
      "houseId": "h6",
      "status": "Por verificar",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "c7",
      "name": "Ciudadano ficticio 07",
      "houseId": "h7",
      "status": "Por verificar",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    },
    {
      "id": "c8",
      "name": "Ciudadano ficticio 08",
      "houseId": "h8",
      "status": "Por verificar",
      "createdAt": "2026-10-23T12:00:00Z",
      "updatedAt": "2026-10-23T12:00:00Z"
    }
  ]
}
SIGEIA_JSON, true, 512, JSON_THROW_ON_ERROR);
