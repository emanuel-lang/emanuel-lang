<?php
if (!defined('SIGEIA_APP')) { http_response_code(403); exit; }
return json_decode(<<<'SIGEIA_JSON'
{
  "regions": {
    "label": "Regiones",
    "singular": "Región",
    "domain": "Territorial",
    "fields": [
      {
        "key": "name",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "key": "code",
        "label": "Clave",
        "type": "text",
        "required": true
      }
    ]
  },
  "territories": {
    "label": "Territorios",
    "singular": "Territorio",
    "domain": "Territorial",
    "fields": [
      {
        "key": "name",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "key": "code",
        "label": "Clave",
        "type": "text",
        "required": true
      },
      {
        "key": "regionId",
        "label": "Región",
        "type": "reference",
        "entity": "regions",
        "required": true
      },
      {
        "key": "polygon",
        "label": "Polígono",
        "type": "polygon"
      }
    ]
  },
  "localities": {
    "label": "Localidades",
    "singular": "Localidad",
    "domain": "Territorial",
    "fields": [
      {
        "key": "name",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "key": "territoryId",
        "label": "Territorio",
        "type": "reference",
        "entity": "territories",
        "required": true
      }
    ]
  },
  "sectors": {
    "label": "Sectores",
    "singular": "Sector",
    "domain": "Territorial",
    "fields": [
      {
        "key": "name",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "key": "localityId",
        "label": "Localidad",
        "type": "reference",
        "entity": "localities",
        "required": true
      }
    ]
  },
  "operators": {
    "label": "Operadores",
    "singular": "Operador",
    "domain": "Operativo",
    "fields": [
      {
        "key": "name",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "key": "roleId",
        "label": "Rol operativo",
        "type": "reference",
        "entity": "roles",
        "required": true
      }
    ]
  },
  "roles": {
    "label": "Roles",
    "singular": "Rol",
    "domain": "Operativo",
    "fields": [
      {
        "key": "name",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "key": "description",
        "label": "Descripción",
        "type": "text",
        "required": false
      }
    ]
  },
  "assignments": {
    "label": "Asignaciones",
    "singular": "Asignación",
    "domain": "Operativo",
    "fields": [
      {
        "key": "operatorId",
        "label": "Operador",
        "type": "reference",
        "entity": "operators",
        "required": true
      },
      {
        "key": "level",
        "label": "Nivel",
        "type": "select",
        "options": [
          "Región",
          "Territorio",
          "Localidad",
          "Sector"
        ],
        "required": true
      },
      {
        "key": "targetId",
        "label": "Unidad territorial",
        "type": "text",
        "required": true
      }
    ]
  },
  "houses": {
    "label": "Casas",
    "singular": "Casa",
    "domain": "Electoral",
    "fields": [
      {
        "key": "name",
        "label": "Identificador",
        "type": "text",
        "required": true
      },
      {
        "key": "address",
        "label": "Dirección",
        "type": "text",
        "required": true
      },
      {
        "key": "sectorId",
        "label": "Sector",
        "type": "reference",
        "entity": "sectors",
        "required": true
      },
      {
        "key": "status",
        "label": "Estado de visita",
        "type": "select",
        "options": [
          "Pendiente",
          "Visitada"
        ],
        "required": true
      },
      {
        "key": "lat",
        "label": "Latitud",
        "type": "number",
        "min": -90,
        "max": 90,
        "required": true
      },
      {
        "key": "lng",
        "label": "Longitud",
        "type": "number",
        "min": -180,
        "max": 180,
        "required": true
      }
    ]
  },
  "citizens": {
    "label": "Ciudadanos",
    "singular": "Ciudadano",
    "domain": "Electoral",
    "fields": [
      {
        "key": "name",
        "label": "Nombre",
        "type": "text",
        "required": true
      },
      {
        "key": "houseId",
        "label": "Casa",
        "type": "reference",
        "entity": "houses",
        "required": true
      },
      {
        "key": "status",
        "label": "Estado de registro",
        "type": "select",
        "options": [
          "Por verificar",
          "Verificado"
        ],
        "required": true
      }
    ]
  }
}
SIGEIA_JSON, true, 512, JSON_THROW_ON_ERROR);
